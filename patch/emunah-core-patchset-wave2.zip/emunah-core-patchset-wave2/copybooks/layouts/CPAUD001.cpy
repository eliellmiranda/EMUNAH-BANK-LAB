*===============================================================*
* COPYBOOK: CPAUD001                                            *
* FUNCAO  : LAYOUT DE AUDITORIA PADRONIZADO                     *
* REGISTRO: 120 BYTES                                           *
* DATASET : Z77948.EMUNAH.ARQ.AUDIT.SEQ                         *
* DDNAME  : AUDIT                                               *
*===============================================================*
     05 AU-TIPO-EVENTO          PIC X(04).
     05 AU-PROGRAMA             PIC X(08).
     05 AU-DATA-EVENTO          PIC 9(08).
     05 AU-HORA-EVENTO          PIC 9(08).
     05 AU-COD-EVENTO           PIC X(10).
     05 AU-CHAVE-REF            PIC X(20).
     05 AU-MENSAGEM             PIC X(50).
     05 AU-COMPLEMENTO          PIC X(12).
