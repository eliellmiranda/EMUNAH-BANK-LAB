      *===============================================================*
      * COPYBOOK: CPSTS001                                            *
      * FUNCAO  : LAYOUT DO CTL.STATUS                                *
      * REGISTRO: 8 BYTES                                             *
      *                                                               *
      * VALORES VALIDOS:                                              *
      *   OPEN    EOTI    EOFI    CLOSED                              *
      *===============================================================*
           05 STS-CODIGO               PIC X(08).
              88 STS-VAZIO             VALUE SPACES.
              88 STS-OPEN              VALUE 'OPEN    '.
              88 STS-EOTI              VALUE 'EOTI    '.
              88 STS-EOFI              VALUE 'EOFI    '.
              88 STS-CLOSED            VALUE 'CLOSED  '.
