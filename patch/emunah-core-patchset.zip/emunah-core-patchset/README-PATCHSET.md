# Emunah Bank Lab — Core Patchset

Este pacote entrega os arquivos reescritos para corrigir a cadeia batch principal.

## Escopo

Foram reescritos os arquivos de maior prioridade:

- `EBJPRECK.jcl`
- `EBJSOD.jcl`
- `EBJCUTF.jcl`
- `EBJCUTE.jcl`
- `EBJSNAP.jcl`
- `EBJCONC.jcl`
- `EBJEOD.jcl`
- `EBDEPLOY.jcl`
- `EBPCHK01.cbl` (novo)
- `EBCTL01.cbl`
- `EBCONC01.cbl`
- `EBJEOD01.cbl`
- `CPSTS001.cpy` (novo)
- `CPSNP001.cpy` (novo)
- `CPCONC01.cpy` (novo)

## Ordem de publicação sugerida

1. Publicar os copybooks
2. Publicar os COBOLs
3. Publicar os JCLs
4. Rodar `EBDEPLOY`
5. Testar a cadeia:
   - `EBJPRECK`
   - `EBJSOD`
   - `EBJBCKPD`
   - `EBJWAIT`
   - `EBJLOAD`
   - `EBJVALD`
   - `EBJPOST`
   - `EBJCUTF`
   - `EBJACCR`
   - `EBJSNAP`
   - `EBJCUTE`
   - `EBJCONC`
   - `EBJEXTR`
   - `EBJEOD`

## Observações

- O HLQ está mantido como `Z77948` para bater com os arquivos atuais do lab.
- `EBJPRECK` agora valida o conteúdo de `CTL.STATUS`, e não só a existência do dataset.
- `EBJSOD`, `EBJCUTF`, `EBJCUTE` e `EBJEOD` passam a usar `EBCTL01`.
- `EBJSNAP` passa a chamar `EBSNAP01` com `SALDOUT`, deixando `EBSALD01` apenas como utilitário manual.
- `EBJCONC` passa a fornecer todos os DDs exigidos por `EBCONC01` e grava `CONCIL.SEQ` com `LRECL=132`.
