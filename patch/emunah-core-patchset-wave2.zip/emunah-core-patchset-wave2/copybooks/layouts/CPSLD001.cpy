*===============================================================*
* COPYBOOK: CPSLD001                                            *
* FUNCAO  : LAYOUT DE POSICAO DE SALDO / SNAPSHOT               *
* REGISTRO: 120 BYTES                                           *
* DATASET : Z77948.EMUNAH.ARQ.SALDO.GDG                         *
* DDNAME  : SALDOIN / SALDOUT                                   *
*===============================================================*
     05 SLD-AGENCIA             PIC 9(04).
     05 SLD-NUM-CONTA           PIC 9(08).
     05 SLD-SALDO               PIC S9(11)V99.
     05 SLD-DATA                PIC 9(08).
     05 FILLER                  PIC X(87).
